Vicuous Dead Screen Test

By: Ryan Liston

Date: Jan. 17, 2020

Description: a screen test for the vicous dead map screen and manual, screen adjustment routine. 

Machine: Commodore Vic 20 with 32k expansion.

Start: load"screen test",8,1

Controls: Up, down, left and right to adjust screen.

